//  Boost utility/nonderivable.hpp header file  ------------------//

//  (C) Copyright Manuel Fiorelli 2007. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org/libs/utility for documentation.

#ifndef BOOST_UTILITY_NONDERIVABLE_HPP
#define BOOST_UTILITY_NONDERIVABLE_HPP

namespace boost
{

	namespace nonderivable_	// Protection from unintended ADL
	{
		/*
		 * Helper class 
		 */ 
		class nonderivable_helper
		{
			friend class nonderivable;
			
			private:
				virtual void uniqueness() = 0; // This will hide uniqueness in derived classes
			
			protected:
				virtual ~nonderivable_helper() {} // included just to avoid some warnings
				
				nonderivable_helper() {}
		};
		
		/*
		 * "nonderivable" derives from the protected virtual base
		 * class nonderivable_helper. By overriding the pure virtual
		 * method uniqueness, it ensures that no class can derive
		 * twice from nonderivable, since it will cause a compilation
		 * error, since there would be more final overriders for the
		 * uniqueness method.
		 */
		class nonderivable : protected virtual nonderivable_helper
		{		
			private:
				virtual void uniqueness() {}
		};
	}
	
	typedef nonderivable_::nonderivable nonderivable;
}

/*
 * Usage ---------------------------------------------------------//
 *
 * Use BOOST_NON_DERIVABLE to define a class whose derived classes
 * shouldn't be instantiated.
 *
 * Suppose you want to define a class Foo, then you have to use the
 * macro as follows:
 *
 *    class Foo : BOOST_NON_DERIVABLE
 *    {
 *        ...
 *    };
 *
 * The class Foo is, in fact, pseudo-final, meaning that you are
 * free to subclass it, altough its derived classes cannot be
 * instantiated.
 * 
 * Techniques ----------------------------------------------------//
 *
 * When you use the BOOST_NON_DERIVABLE macro as suggested, in fact
 * you use boost::nonderivable_helper as private virtual base class.
 * Protected members are accessible within the direct subclass, but
 * they aren't in indirect subclasses, since you use the private
 * inheritance. Beside, the virtual base class has to be initialized
 * in every subclass (not only in the direct subclass), thus when
 * you try to instantiate an indirect subclass, you will attempt to
 * use an unaccessible member (the default constructor of 
 * nonderivable_helper), which produces a compilation error.
 * Suppose Foo to be a final class, then one could write
 * class Goo : public Foo, BOOST_NON_DERIVABLE
 * {
 *    // ...
 * };
 * If Goo could derive from BOOST_NON_DERIVABLE, then the constructor
 * would be accessible and Goo would be constructible; fortunately,
 * (as explained above) it is impossible to derive a class twice 
 * from nonderivable, so that this backdoor is not usable.
 */
#define BOOST_NON_DERIVABLE private ::boost::nonderivable

#endif // BOOST_UTILITY_NONDERIVABLE_HPP


