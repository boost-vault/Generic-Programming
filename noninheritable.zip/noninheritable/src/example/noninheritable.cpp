//
// Copyright (c) 2006 Vladislav Lazarenko <snail@b2bits.com>
//
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/noninheritable.hpp>

// This class will be noninheritable.
// It will be impossible to inherit from this class.
class UniquePerson : public boost::noninheritable<UniquePerson>
{
public:
  UniquePerson() {}
  ~UniquePerson() {}

  void doSomething() {}
};

/*
    // This code will not be compiled because UniquePerson class
    // is noninheritable.
    class BadMonster : public UniquePerson
    {
    public:
      BadMonster() {}
      ~BadMonster() {}
    };

    // This code probably will be compiled, but it can't
    // be used. The error will be raised on compile time when you will
    // try to instantinate the class or one of its child.
    class AwfulMonster : public UniquePerson {};
*/
