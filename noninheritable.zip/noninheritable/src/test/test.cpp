//
// Copyright (c) 2006 Vladislav Lazarenko <snail@b2bits.com>
//
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/test/unit_test.hpp>

using namespace boost::unit_test_framework;

extern void test_template_friend();
extern void test_noninheritable();

test_suite *init_unit_test_suite(int, char ** const)
{
  test_suite *test = BOOST_TEST_SUITE("Boost Noninheritable test suite");

  test->add(BOOST_TEST_CASE(&test_template_friend));
  test->add(BOOST_TEST_CASE(&test_noninheritable));

  return test;
}
