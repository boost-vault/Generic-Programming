//
// Copyright (c) 2006 Vladislav Lazarenko <snail@b2bits.com>
//
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/template_friend.hpp>
#include <boost/test/unit_test.hpp>

namespace
{
  template <typename T1, typename T2>
  class A
  {
    BOOST_DECLARE_TEMPLATE_FRIEND(T1);
    BOOST_DECLARE_TEMPLATE_FRIEND(T2);

  private:
    A() {}
    ~A() {}

    int test() const
    {
      return 0;
    }
  };

  class B;
  class C;

  typedef A<B, C> Friendly;

  class B
  {
  public:
    B() {}
    ~B() {}

    int test() const
    {
      Friendly t;
      return t.test();
    }
  };

  class C
  {
  public:
    C() {}
    ~C() {}

    int test() const
    {
      Friendly t;
      return t.test();
    }
  };
}

using namespace boost::unit_test_framework;

void test_template_friend()
{
  BOOST_CHECKPOINT("Testing template friends");

  const B b;
  const C c;

  BOOST_CHECK(b.test() == 0);
  BOOST_CHECK(c.test() == 0);
}
