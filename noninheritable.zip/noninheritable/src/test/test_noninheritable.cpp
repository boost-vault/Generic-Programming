//
// Copyright (c) 2006 Vladislav Lazarenko <snail@b2bits.com>
//
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#include <boost/noninheritable.hpp>
#include <boost/test/unit_test.hpp>

using namespace boost::unit_test_framework;

namespace
{
  class UniquePerson : public boost::noninheritable<UniquePerson>
  {
  public:
    UniquePerson() {}
    ~UniquePerson() {}

    void doSomething() {}
  };
}

void test_noninheritable()
{
  BOOST_CHECKPOINT("Testing noninheritable class");

  UniquePerson person;
  person.doSomething();
}
