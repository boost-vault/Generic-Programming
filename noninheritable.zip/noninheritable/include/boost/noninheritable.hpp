//
// Copyright (c) 2006 Vladislav Lazarenko <snail@b2bits.com>
//
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef BOOST_NONINHERITABLE_HPP
#define BOOST_NONINHERITABLE_HPP

#include <boost/config.hpp>
#include <boost/detail/workaround.hpp>
#include <boost/template_friend.hpp>

// MS compatible compilers support #pragma once.
#if BOOST_WORKAROUND(BOOST_MSVC, >= 1020)
# pragma once
#endif

#define BOOST_DECLARE_SEALED(T)           \
   class boost_sealed_impl_##T {          \
     friend class T;                      \
   private:                               \
     boost_sealed_impl_##T() {}           \
     ~boost_sealed_impl_##T() {}          \
   };

#define BOOST_IMPLEMENT_SEALED(T)         \
   virtual private boost_sealed_impl_##T

/*! \file
    Non-inheritable template.
 */

namespace boost
{
  // Protection from unintended ADL.
  namespace noninheritable_
  {
    template <typename T1, typename T2>
    class noninheritable_impl
    {
      BOOST_DECLARE_TEMPLATE_FRIEND(T1);
      BOOST_DECLARE_TEMPLATE_FRIEND(T2);

    public:
      //! Copy constructor.
      noninheritable_impl(const noninheritable_impl &) {}

      //! Copy operator.
      noninheritable_impl & operator = (const noninheritable_impl &) { return *this; }

    private:
      /*
        NOTE TO USER:

        Compile error from here indicates that you has specified noninheritable class
        as the base class of another class.

        The noninheritable classes is used to prevent derivation from a class.
        An error occurs if a noninheritable class is specified as the base class of
        another class. A noninheritable class cannot also be an abstract class.

        The analogue of this class in other languages:
        
          1) Java - final
          2) C# - sealed
      */

      //! Constructor.
      noninheritable_impl() {}

      //! Destructor.
      ~noninheritable_impl() {}
    };
  }

  //! Noninheritable class.
  /*!
      The noninheritable classes is used to prevent derivation from a class.
      An error occurs if a noninheritable class is specified as the base class of another class.
      A noninheritable class cannot also be an abstract class.
  */
  template <typename T>
  class noninheritable :
    virtual private noninheritable_::noninheritable_impl<noninheritable, T>
  {
  public:
    //! Constructor.
    noninheritable() {}

    //! Destructor.
    ~noninheritable() {}

    //! Copy constructor.
    noninheritable(const noninheritable &) {}

    //! Copy operator.
    noninheritable & operator = (const noninheritable &) { return *this; }
  };
}

#endif // BOOST_NONINHERITABLE_HPP
