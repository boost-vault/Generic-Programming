//
// Copyright (c) 2006 Matthew Wilson <matthew@synesis.com.au>
// Copyright (c) 2006 Vladislav Lazarenko <snail@b2bits.com>
//
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef BOOST_TEMPLATE_FRIEND_HPP
#define BOOST_TEMPLATE_FRIEND_HPP

#include <boost/config.hpp>
#include <boost/detail/workaround.hpp>

// MS compatible compilers support #pragma once.
#if BOOST_WORKAROUND(BOOST_MSVC, >= 1020)
# pragma once
#endif

/*! \file
    Workaround for template friends.
 */

#if BOOST_WORKAROUND(__GNUC__, < 3) ||                    \
    defined(__BORLANDC__) ||                              \
    defined(__COMO__) ||                                  \
    defined(__DMC__) ||                                   \
    defined(__WATCOMC__) ||                               \
    defined(BOOST_MSVC)  ||                               \
    defined(BOOST_INTEL)
# define BOOST_DECLARE_TEMPLATE_FRIEND(T) friend T
#elif defined(__MWERKS__)
# define BOOST_DECLARE_TEMPLATE_FRIEND(T) friend class T
#elif BOOST_WORKAROUND(__GNUC__, >= 3)
# define BOOST_DECLARE_TEMPLATE_FRIEND(T)                 \
  struct make_friend_##T                                  \
  {                                                       \
    typedef T T2;                                         \
  };                                                      \
  typedef typename make_friend_##T::T2 friend_type_##T;   \
  friend friend_type_##T
#else
// We can not list all compilers and suppose that other compilers supports this.
# define BOOST_DECLARE_TEMPLATE_FRIEND(T) friend T
#endif

#endif  // BOOST_TEMPLATE_FRIEND_HPP
