#include <boost/test/auto_unit_test.hpp>

#include "boost/static_lambda/functor.hpp"
#include "boost/static_lambda/placeholder.hpp"
#include "boost/static_lambda/expression.hpp"
#include <boost/static_assert.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/typeof/typeof.hpp>
namespace
{

  using namespace boost::static_lambda::tag;
  using namespace boost::static_lambda;
  struct tag1;
  struct tag2;
  struct tag3;

  expression<tag1> expr1;
  expression<tag2> expr2;
  expression<tag3> expr3;

  BOOST_STATIC_ASSERT((boost::is_same<
    BOOST_TYPEOF(expr1()),
    expression<function_call0<tag1> >
  >::value)); 
  BOOST_STATIC_ASSERT((boost::is_same<
    BOOST_TYPEOF(expr1(expr1)),
    expression<function_call1<tag1, tag1> >
  >::value)); 
  BOOST_STATIC_ASSERT((boost::is_same<
    BOOST_TYPEOF(expr3(expr2)),
    expression<function_call1<tag3, tag2> >
  >::value)); 

  char invoke(char c)
  {
    return c;
  }

  void v()
  {
  }

}

BOOST_AUTO_TEST_CASE(test_expression)
{
  //to_functor(_1())(&v);
  const char * hw = "hello world";
  BOOST_CHECK(to_functor(_1[_2])(hw, 4) == hw[4]);
  BOOST_CHECK(to_functor(_1(_2))(&invoke, 'x') == invoke('x'));
}
