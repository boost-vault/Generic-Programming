#include <boost/test/auto_unit_test.hpp>


#include "boost/static_lambda/operator.hpp"
#include "boost/static_lambda/functor.hpp"
#include "boost/static_lambda/placeholder.hpp"
using namespace boost::static_lambda::expr;
using namespace boost::static_lambda;
BOOST_AUTO_TEST_CASE(test_operator)
{
	BOOST_CHECK(to_functor(_1 + _2)(34, 51) == 85);
	BOOST_CHECK(to_functor(_1 + _2 * _3 + _2)(59, 34, 51) == 59 + 34 * 51 + 34);
	BOOST_CHECK(to_functor(_1 + (_2 << _3) + _2)(59, 34, 5) == 59 + (34 << 5) + 34);
	BOOST_CHECK(to_functor((_1 + _2) << (_3 + _2))(59, 5, 12) == (59 + 5) << (12 + 5));
	BOOST_CHECK(to_functor(_1 << _2)(59U, 31) == 59U << 31);
	int a = 2451;
	BOOST_CHECK(to_functor(*_1)(&a) == a);
}
