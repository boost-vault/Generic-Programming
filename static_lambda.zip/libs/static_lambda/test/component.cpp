#include <boost/test/auto_unit_test.hpp>
#include <boost/static_lambda.hpp>
#include <cstddef>
class component_a
{
public:
  int foo()
  {
    return 1;
  }
};

template<typename Locator_A>
class component_b
{
public:
  void bar()
  {
    BOOST_CHECK(Locator_A::static_invoke(this)->foo() == 1);
  }
};



struct locator_to_a;
class global_object
{
public:
  component_a a_;
  component_b<locator_to_a> b_;
  global_object() : a_(), b_()
  {
    b_.bar();
  }
};

// declare constant "offset_of_a".
BOOST_STATIC_LAMBDA_AUTO_EXPRESSION(offset_of_a, offsetof(global_object, a_));

// declare constant "offset_of_b".
BOOST_STATIC_LAMBDA_AUTO_EXPRESSION(offset_of_b, offsetof(global_object, b_));

using namespace boost::static_lambda;

// the static lambda function. note: constructing a pointer equals to casting to a pointer.
typedef BOOST_STATIC_LAMBDA_FUNCTOR
(
  construct<component_a*>
  (
    construct<char*>(_1) - offset_of_b + offset_of_a
  )
) l;
struct locator_to_a : l{};
BOOST_AUTO_TEST_CASE(test_component)
{
  global_object g;
}
