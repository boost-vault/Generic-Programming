#include <boost/test/auto_unit_test.hpp>

#include "boost/static_lambda/placeholder.hpp"
#include "boost/static_lambda/operator.hpp"
#include "boost/static_lambda/functor.hpp"
#include "boost/static_lambda/mpl_constant.hpp"
using namespace boost::static_lambda;
using namespace boost::static_lambda::expr;

BOOST_AUTO_TEST_CASE(test_mpl_constant)
{
	BOOST_CHECK(to_functor(_1 == int_<6>())(6));
}
