#include <boost/test/auto_unit_test.hpp>

#include "boost/static_lambda/placeholder.hpp"
#include "boost/static_lambda/functor.hpp"
#include <boost/static_assert.hpp>
#include <boost/type_traits/is_same.hpp>
//#include <boost/typeof/typeof.hpp>
using namespace boost::static_lambda;

namespace
{
	int xxx()
	{
		return 1999;
	}
	
	struct add
	{
          template<typename>
          struct result;

          template<typename T>
          struct result<add (T, T)>
          {
            typedef T type;
          };
          template<typename T>
          struct result<add (T, T, T)>
          {
            typedef T type;
          };
		template<typename T>
		T operator()(T l, T r)
		{
			return l + r;
		}
		
		template<typename T>
		T operator()(T t0, T t1, T t2)
		{
			return t0 + t1 + t2;
		}
	};
	struct sub
	{
          template<typename>
          struct result;

          template<typename T>
          struct result<sub (T, T)>
          {
            typedef T type;
          };
		template<typename T>
		T operator()(T l, T r)
		{
			return l - r;
		}
	};
	int r(int i)
	{
		return i + 1;
	}
	struct R
	{
          template<typename>
          struct result;

          template<typename T>
          struct result<R (T)>
          {
            typedef T type;
          };
		template<typename T>
		T operator ()(T i)
		{
			return i - 1;
		}
	};
	int m(int l, int r)
	{
		return l * r;
	}
}
BOOST_AUTO_TEST_CASE(test_placeholder)
{
	BOOST_CHECK(to_functor(_1).number_of_arguments == 1);
	BOOST_CHECK(to_functor(_1)(2) == 2);
	BOOST_CHECK(to_functor(_3).number_of_arguments == 3);
	BOOST_CHECK(to_functor(_4)(1, 2, 3, 5) == 5);
	BOOST_CHECK(to_functor(_1())(&xxx) == 1999);
	BOOST_CHECK(to_functor(_1(_2))(&r, 56) == 57);

	BOOST_CHECK(to_functor(_2(_1))(56, R()) == 55);
	_2(_1,_3);
	to_functor(_2(_1, _3));
	BOOST_CHECK(to_functor(_2(_1, _3)).number_of_arguments == 3);
	BOOST_CHECK(to_functor(_2(_1, _3))(5, &m, 7) == 35);
	
	{
		sub s;
		BOOST_CHECK(to_functor(_2(_1, _3))(1, s, 4) == -3);
	}
	
	{
		sub s;
		add a;
		BOOST_CHECK
		(
			to_functor
			(
				_1(_3(_3(_2, _2), _2, _4), _2)
			)
			(s, 3, a, 11)
			==
			17
		);
	}
}
