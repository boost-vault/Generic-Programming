#include <boost/test/auto_unit_test.hpp>

#include "boost/static_lambda/placeholder.hpp"
#include "boost/static_lambda/functor.hpp"
#include "boost/static_lambda/constant.hpp"
#include "boost/static_lambda/inplace_executor.hpp"

#include <boost/static_assert.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/mpl/int.hpp>
using namespace boost::static_lambda;
using namespace boost::static_lambda::expr;

namespace
{
int a = 5;

double add(double l, double r)
{
	return l + r;
}
int sub(int l, int r)
{
	return l - r;
}
BOOST_STATIC_LAMBDA_AUTO_EXPRESSION(a_e, a);
BOOST_STATIC_LAMBDA_AUTO_EXPRESSION(d_e, 1.25);
BOOST_STATIC_LAMBDA_AUTO_EXPRESSION(add_e, &add);
BOOST_STATIC_LAMBDA_AUTO_EXPRESSION(sub_e, &sub);
}
BOOST_AUTO_TEST_CASE(test_constant)
{
	BOOST_CHECK(to_functor(add_e(a_e, d_e))() == add(a, 1.25));
	BOOST_CHECK(to_functor(a_e)() == a);
	BOOST_CHECK(to_functor(constant<boost::mpl::int_<5> >())() == 5);
	BOOST_CHECK(to_functor(sub_e(constant<boost::mpl::int_<62> >(), a_e))() == 57);
}
