#include <boost/test/auto_unit_test.hpp>
#include <boost/ref.hpp>
#include <boost/type_traits/is_same.hpp>

#include "boost/static_lambda.hpp"
#include <iostream>
namespace
{
  double x(int,int)
  {
    return 2;
  }
}
BOOST_AUTO_TEST_CASE(test_hello_world)
{
  using namespace boost::static_lambda::expr;
  using namespace boost::static_lambda;
  using namespace std;
  using namespace boost;


  to_functor(expr::add_reference(expr::add_reference(_1 << _2) << _3));
  to_functor(expr::add_reference(expr::add_reference(_1 << _2) << _3)).operator()<ostream&>(cout, "hello ", "world");
  BOOST_CHECK(cout.good());
  to_functor(expr::add_reference(expr::add_reference(_1 << _2) << _3)).static_invoke<ostream&>(cout, "hello ", "world");
  BOOST_CHECK(cout.good());
  to_functor(expr::add_reference(expr::add_reference(_1 << _2) << _3)).static_invoke<ostream&>(cout, "hello world", &endl<char, char_traits<char> >);
  BOOST_CHECK(cout.good());
  to_functor(expr::add_reference(expr::add_reference(construct<ostream&>(_1) << _2) << _3))(ref(cout), "hello world", &endl<char, char_traits<char> >);
  BOOST_CHECK(cout.good());
}
