#define BOOST_TEST_MODULE static_lambda
#include <boost/test/auto_unit_test.hpp>
