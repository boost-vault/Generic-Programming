#include <boost/test/auto_unit_test.hpp>

#include "boost/static_lambda/inplace_executor.hpp"
#include "boost/static_lambda/placeholder.hpp"
#include "boost/static_lambda/functor.hpp"
#include "boost/static_lambda/constant.hpp"
#include "boost/static_lambda/construct.hpp"
#include <boost/static_assert.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/mpl/int.hpp>
using namespace boost::static_lambda;
using namespace boost::static_lambda::expr;

namespace
{

struct ss
{
	int a_;
	int b_;
	ss(int a, int b)
		: a_(a)
		, b_(b)
	{
	}
	static int result(ss s)
	{
		return s.a_ + s.b_;
	}
};
BOOST_STATIC_LAMBDA_AUTO_EXPRESSION(t, 12);
int(*rrr)(ss) = &ss::result;
BOOST_STATIC_LAMBDA_AUTO_EXPRESSION(r, rrr);

}
BOOST_AUTO_TEST_CASE(test_construct)
{
	BOOST_CHECK(to_functor(r(construct<ss>(t,_1)))(88) == 100);
}
