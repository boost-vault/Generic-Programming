#include <boost/test/auto_unit_test.hpp>

#include "boost/static_lambda/inplace_executor.hpp"
#include "boost/static_lambda/placeholder.hpp"
#include "boost/static_lambda/functor.hpp"
#include "boost/static_lambda/constant.hpp"
#include "boost/static_lambda/construct.hpp"
#include <boost/static_assert.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/mpl/int.hpp>
using namespace boost::static_lambda;
using namespace boost::static_lambda::expr;

namespace
{

struct ss
{
	int a_;
	int b_;
	ss(int a, int b)
		: a_(a)
		, b_(b)
	{
	}
	static int result(ss& s)
	{
		return s.a_ + s.b_;
	}
};
BOOST_STATIC_LAMBDA_AUTO_EXPRESSION(r, &ss::result);
BOOST_STATIC_LAMBDA_AUTO_EXPRESSION(t, 12);

int add(int l, int r)
{
	return l + r;
}
BOOST_STATIC_LAMBDA_AUTO_EXPRESSION(add_e, &add);
        struct a{};
        struct b{};

}
BOOST_AUTO_TEST_CASE(test_local)
{
  get<struct b>();
	BOOST_CHECK
	(
		to_functor(
			local<ss, struct a>(t, _1,
			(
				r(get<struct a>())
			))
		)
		(88)
		 ==
		100
	);

        BOOST_CHECK
	(
		to_functor(
			local<struct b>(add_e(_1, _2),
			(
				add_e(get<struct b>(), _2)
			))
		)
		(5, 7)
		 ==
		19
	);
	
}
