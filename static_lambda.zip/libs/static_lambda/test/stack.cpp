#include <boost/test/auto_unit_test.hpp>


#include "boost/static_lambda/detail/stack.hpp"
#include <boost/mpl/list.hpp>

static int foo()
{
  return 0;
}

using namespace boost::static_lambda::detail;
using namespace boost::mpl;
namespace
{
  struct a{};
  struct b{};
}

BOOST_AUTO_TEST_CASE(test_stack1)
{
  int a = 1;
  vector_node<list<int&>, list<struct a> >::type v = {a};
  get<struct a>(v)++;
  BOOST_CHECK(a == 2);
}
BOOST_AUTO_TEST_CASE(test_stack2)
{
  int a = 10;
  vector_node<list<int>, list<struct a> >::type v = {a};

  get<struct a>(v)++;
  BOOST_CHECK(a == 10);
}
BOOST_AUTO_TEST_CASE(test_stack3)
{
  int a = 5;
  int b = 50;
  vector_node<list<int, int&>, list<struct a,struct b> >::type v = {a, b};
  BOOST_CHECK(get<struct a>(v) == 5);
  BOOST_CHECK(get<struct b>(v) == 50);
  get<struct a>(v)++;
  get<struct b>(v)--;
  BOOST_CHECK(get<struct a>(v) == 6);
  BOOST_CHECK(get<struct b>(v) == 49);
  BOOST_CHECK(a == 5);
  BOOST_CHECK(b == 49);
}




