#ifndef EXPRESSION_HPP_
#define EXPRESSION_HPP_
#include "executor.hpp"
#include "detail/utility.hpp"
#include <boost/config.hpp>
#include <boost/mpl/if.hpp>
#include <boost/typeof/typeof.hpp>
#include <boost/type_traits/add_reference.hpp>
#include <boost/type_traits/remove_reference.hpp>
#include <boost/utility/result_of.hpp>
#include <boost/preprocessor/repetition/enum.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/enum_trailing_params.hpp>
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/arithmetic/inc.hpp>
namespace boost
{
namespace static_lambda
{
namespace tag
{
#define BOOST_STATIC_LAMBDA_FUNCTION_CALL_TAG(z, n, _) \
template<typename Function_Tag BOOST_PP_ENUM_TRAILING_PARAMS_Z(z,n,typename Argument_Tag)> \
struct BOOST_PP_CAT(function_call, n); \
/**/
BOOST_PP_REPEAT(10, BOOST_STATIC_LAMBDA_FUNCTION_CALL_TAG, nil)
#undef BOOST_STATIC_LAMBDA_FUNCTION_CALL_TAG

template<typename Array, typename Index>
struct subscript;
template<typename L, typename R>
struct assign;
}

template<typename Tag>
struct expression
{
  expression<tag::function_call0<Tag> > operator()()
  {
    expression<tag::function_call0<Tag> > ret;
    return ret;
  }
#define BOOST_STATIC_LAMBDA_GET_PARAMETER(z,n,_) \
  expression<BOOST_PP_CAT(Argument_Tag, n)>\
/**/
#define BOOST_STATIC_LAMBDA_EXPRESSION_OPERATOR_FUNCTION_CALL(z, n, _) \
  template<BOOST_PP_ENUM_PARAMS_Z(z,n,typename Argument_Tag)>\
  expression<BOOST_PP_CAT(tag::function_call, n)<Tag, BOOST_PP_ENUM_PARAMS_Z(z, n, Argument_Tag)> > operator()(BOOST_PP_CAT(BOOST_PP_ENUM_, z)(n, BOOST_STATIC_LAMBDA_GET_PARAMETER, nil))\
  {\
    expression<BOOST_PP_CAT(tag::function_call, n)<Tag, BOOST_PP_ENUM_PARAMS_Z(z, n, Argument_Tag)> > ret;\
    return ret;\
  }\
/**/
#define BOOST_STATIC_LAMBDA_EXPRESSION_OPERATOR_FUNCTION_CALL_INC(z,n,_) \
  BOOST_STATIC_LAMBDA_EXPRESSION_OPERATOR_FUNCTION_CALL(z, BOOST_PP_INC(n),_)
/**/
BOOST_PP_REPEAT(9, BOOST_STATIC_LAMBDA_EXPRESSION_OPERATOR_FUNCTION_CALL_INC, nil)
#undef BOOST_STATIC_LAMBDA_EXPRESSION_OPERATOR_FUNCTION_CALL
#undef BOOST_STATIC_LAMBDA_EXPRESSION_OPERATOR_FUNCTION_CALL_INC
#undef BOOST_STATIC_LAMBDA_GET_PARAMETER


template<typename Index>
expression<tag::subscript<Tag, Index> > operator[](expression<Index>)
{
  expression<tag::subscript<Tag, Index> > ret;
  return ret;
}
template<typename R>
expression<tag::assign<Tag, R> > operator=(expression<R>)
{
  expression<tag::assign<Tag, R> > ret;
  return ret;
}


};



#define BOOST_STATIC_LAMBDA_EXECUTE_ARGUMENT(z,n,_) \
  executor<BOOST_PP_CAT(Argument_Tag, n), Stack>::execute(stack) \
/**/
#ifdef BOOST_MSVC

#define BOOST_STATIC_LAMBDA_MAKE_ARGUMENT(z, n, _) \
  typename boost::remove_reference<typename executor<BOOST_PP_CAT(Argument_Tag, n), Stack>::result_type>::type \
/**/

#define BOOST_STATIC_LAMBDA_FUNCTION_CALL_EXECUTOR(z,n,_) \
template<typename Tag BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, typename Argument_Tag), typename Stack>\
struct result<BOOST_PP_CAT(tag::function_call, n)<Tag BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, Argument_Tag)>, Stack>\
{\
  typedef typename boost::result_of<typename boost::remove_reference<typename executor<Tag, Stack>::result_type>::type (BOOST_PP_CAT(BOOST_PP_ENUM_, z)(n, BOOST_STATIC_LAMBDA_MAKE_ARGUMENT, nil))>::type type;\
};\
template<typename Tag BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, typename Argument_Tag), typename Stack, typename Result_Type>\
struct modified_executor<BOOST_PP_CAT(tag::function_call, n)<Tag BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, Argument_Tag)>, Stack, Result_Type>\
{\
  static Result_Type execute(Stack& stack)\
  {\
    return executor<Tag, Stack>::execute(stack)\
    (BOOST_PP_CAT(BOOST_PP_ENUM_, z)(n, BOOST_STATIC_LAMBDA_EXECUTE_ARGUMENT, nil));\
  }\
};\
/**/

#else

#define BOOST_STATIC_LAMBDA_MAKE_ARGUMENT(z, n, _) \
  detail::make<typename executor<BOOST_PP_CAT(Argument_Tag, n), Stack>::result_type>() \
/**/


#define BOOST_STATIC_LAMBDA_FUNCTION_CALL_EXECUTOR(z,n,_) \
template<typename Tag BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, typename Argument_Tag), typename Stack>\
struct result<BOOST_PP_CAT(tag::function_call, n)<Tag BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, Argument_Tag)>, Stack>\
{\
  typedef BOOST_TYPEOF_TPL\
  ((\
	  detail::make<typename executor<Tag, Stack>::result_type>()(BOOST_PP_CAT(BOOST_PP_ENUM_, z)(n, BOOST_STATIC_LAMBDA_MAKE_ARGUMENT, nil))\
  )) type;\
};\
template<typename Tag BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, typename Argument_Tag), typename Stack, typename Result_Type>\
struct modified_executor<BOOST_PP_CAT(tag::function_call, n)<Tag BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, Argument_Tag)>, Stack, Result_Type>\
{\
  static Result_Type execute(Stack& stack)\
  {\
    return executor<Tag, Stack>::execute(stack)\
    (BOOST_PP_CAT(BOOST_PP_ENUM_, z)(n, BOOST_STATIC_LAMBDA_EXECUTE_ARGUMENT, nil));\
  }\
};\
/**/
#endif
BOOST_PP_REPEAT(10, BOOST_STATIC_LAMBDA_FUNCTION_CALL_EXECUTOR, nil)
#undef BOOST_STATIC_LAMBDA_FUNCTION_CALL_EXECUTOR
#undef BOOST_STATIC_LAMBDA_EXECUTE_ARGUMENT
#undef BOOST_STATIC_LAMBDA_MAKE_ARGUMENT



template<typename Array, typename Index, typename Stack>
struct result<tag::subscript<Array, Index>, Stack>
{
	typedef BOOST_TYPEOF_TPL
	((
		detail::make<typename executor<Array, Stack>::result_type>()
		[detail::make<typename executor<Index, Stack>::result_type>()]
	)) type;
};

template<typename Array, typename Index, typename Stack, typename Result_Type>
struct modified_executor<tag::subscript<Array, Index>, Stack, Result_Type>
{
	static Result_Type execute(Stack& stack)
	{
		return executor<Array, Stack>::execute(stack)[executor<Index, Stack>::execute(stack)];
	}
};

template<typename L, typename R, typename Stack>
struct result<tag::assign<L, R>, Stack>
{
  typedef BOOST_TYPEOF_TPL
  ((
    detail::make<typename executor<L, Stack>::result_type>()
    =
    detail::make<typename executor<R, Stack>::result_type>()
  )) type;
};
template<typename L, typename R, typename Stack, typename Result_Type>
struct modified_executor<tag::assign<L, R>, Stack, Result_Type>
{
	static Result_Type execute(Stack& stack)
	{
		return executor<L, Stack>::execute(stack) = executor<R, Stack>::execute(stack);
	}
};

}
}

#endif /*EXPRESSION_HPP_*/
