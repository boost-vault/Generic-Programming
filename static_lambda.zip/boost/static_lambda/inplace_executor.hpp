#ifndef INPLACE_EXECUTOR_HPP_
#define INPLACE_EXECUTOR_HPP_

#include "executor.hpp"
namespace boost
{
namespace static_lambda
{

namespace tag
{
template<template<typename> class Result_Impl, template<typename, typename> class Executor_Impl>
struct inplace_executor;
}

template<template<typename> class Result_Impl, template<typename, typename> class Executor_Impl, typename Stack, typename Result_Type>
struct modified_executor<tag::inplace_executor<Result_Impl, Executor_Impl>, Stack, Result_Type> : Executor_Impl<Stack, Result_Type> {};

template<template<typename> class Result_Impl, template<typename, typename> class Executor_Impl, typename Stack>
struct result<tag::inplace_executor<Result_Impl, Executor_Impl>, Stack> : Result_Impl<Stack> {};


}
}


#define BOOST_STATIC_LAMBDA_DECLARE_EXPRESSION(t, n, v) \
template<typename Stack>\
struct n##_result\
{\
  typedef t type;\
};\
template<typename Stack, typename Result_Type>\
struct n##_executor\
{\
  static Result_Type execute(Stack&)\
  {\
    return v;\
  }\
};\
::boost::static_lambda::expression< ::boost::static_lambda::tag::inplace_executor<n##_result, n##_executor> > n;\
/**/
#define BOOST_STATIC_LAMBDA_AUTO_EXPRESSION(name, value) BOOST_STATIC_LAMBDA_DECLARE_EXPRESSION(BOOST_TYPEOF(value), name, value)
#define BOOST_STATIC_LAMBDA_AUTO_EXPRESSION_TPL(name, value) BOOST_STATIC_LAMBDA_DECLARE_EXPRESSION(BOOST_TYPEOF_TPL(value), name, value)

#endif /*MODIFIED_RETURN_HPP_*/
