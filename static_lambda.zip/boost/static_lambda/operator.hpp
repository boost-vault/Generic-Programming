#ifndef BOOST_STATIC_LAMBDA_OPERATOR_HPP_
#define BOOST_STATIC_LAMBDA_OPERATOR_HPP_
#include "expression.hpp"
#include "executor.hpp"
#include "detail/utility.hpp"
namespace boost
{
namespace static_lambda
{

#define BOOST_STATIC_LAMBDA_BINARY_OPERATOR(name, op) \
namespace tag\
{\
template<typename, typename>\
struct name;\
}\
namespace expr\
{\
template<typename L, typename R>\
expression<tag::name<L,R> > operator op(expression<L>, expression<R>)\
{\
  expression<tag::name<L,R> > ret;\
  return ret;\
}\
}\
template<typename L, typename R, typename Stack>\
struct result<tag::name<L, R>, Stack>\
{\
  typedef BOOST_TYPEOF_TPL\
  ((\
    detail::make<typename executor<L, Stack>::result_type>()\
      op\
    detail::make<typename executor<R, Stack>::result_type>()\
  )) type;\
};\
template<typename L, typename R, typename Stack, typename Result_Type>\
struct modified_executor<tag::name<L, R>, Stack, Result_Type>\
{\
  static Result_Type execute(Stack& stack)\
  {\
    return executor<L, Stack>::execute(stack) op executor<R, Stack>::execute(stack);\
  }\
};\
/**/

BOOST_STATIC_LAMBDA_BINARY_OPERATOR(multiply, *)
BOOST_STATIC_LAMBDA_BINARY_OPERATOR(divide, /)
BOOST_STATIC_LAMBDA_BINARY_OPERATOR(modulus, %)

BOOST_STATIC_LAMBDA_BINARY_OPERATOR(addition, +)
BOOST_STATIC_LAMBDA_BINARY_OPERATOR(subtraction, -)

BOOST_STATIC_LAMBDA_BINARY_OPERATOR(shift_right, >>)
BOOST_STATIC_LAMBDA_BINARY_OPERATOR(shift_left, <<)

BOOST_STATIC_LAMBDA_BINARY_OPERATOR(multiply_assign, *=)
BOOST_STATIC_LAMBDA_BINARY_OPERATOR(divide_assign, /=)
BOOST_STATIC_LAMBDA_BINARY_OPERATOR(modulus_assign, %=)

BOOST_STATIC_LAMBDA_BINARY_OPERATOR(add_assign, +=)
BOOST_STATIC_LAMBDA_BINARY_OPERATOR(subtract_assign, -=)

BOOST_STATIC_LAMBDA_BINARY_OPERATOR(shift_right_assign, >>=)
BOOST_STATIC_LAMBDA_BINARY_OPERATOR(shift_left_assign, <<=)

BOOST_STATIC_LAMBDA_BINARY_OPERATOR(equal_to, ==)
BOOST_STATIC_LAMBDA_BINARY_OPERATOR(not_equal_to, !=)

BOOST_STATIC_LAMBDA_BINARY_OPERATOR(less_than, <)
BOOST_STATIC_LAMBDA_BINARY_OPERATOR(greater_than, >)
BOOST_STATIC_LAMBDA_BINARY_OPERATOR(less_than_or_equal_to, <=)
BOOST_STATIC_LAMBDA_BINARY_OPERATOR(greater_than_or_equal_to, >=)

BOOST_STATIC_LAMBDA_BINARY_OPERATOR(bitwise_and, &)
BOOST_STATIC_LAMBDA_BINARY_OPERATOR(bitwise_exclusive_or, ^)
BOOST_STATIC_LAMBDA_BINARY_OPERATOR(bitwise_inclusive_or, |)

BOOST_STATIC_LAMBDA_BINARY_OPERATOR(bitwise_and_assign, &=)
BOOST_STATIC_LAMBDA_BINARY_OPERATOR(bitwise_exclusive_or_assign, ^=)
BOOST_STATIC_LAMBDA_BINARY_OPERATOR(bitwise_inclusive_or_assign, |=)

BOOST_STATIC_LAMBDA_BINARY_OPERATOR(logic_and, &&)
BOOST_STATIC_LAMBDA_BINARY_OPERATOR(logic_or, ||)

#define BOOST_STATIC_LAMBDA_COMMA ,
BOOST_STATIC_LAMBDA_BINARY_OPERATOR(comma, BOOST_STATIC_LAMBDA_COMMA)
#undef BOOST_STATIC_LAMBDA_COMMA

BOOST_STATIC_LAMBDA_BINARY_OPERATOR(pointer_to_member, ->*)

#undef BOOST_STATIC_LAMBDA_BINARY_OPERATOR




#define BOOST_STATIC_LAMBDA_UNARY_OPERATOR(name, op) \
namespace tag\
{\
template<typename>\
struct name;\
}\
namespace expr\
{\
template<typename Operand>\
expression<tag::name<Operand> > operator op(expression<Operand>)\
{\
	expression<tag::name<Operand> > ret;\
	return ret;\
}\
}\
template<typename Operand, typename Stack>\
struct result<tag::name<Operand>, Stack>\
{\
	typedef BOOST_TYPEOF_TPL\
	((\
		op detail::make<typename executor<Operand, Stack>::result_type>()\
	)) type;\
};\
template<typename Operand, typename Stack, typename Result_Type>\
struct modified_executor<tag::name<Operand>, Stack, Result_Type>\
{\
	static Result_Type execute(Stack& stack)\
	{\
		return op executor<Operand, Stack>::execute(stack);\
	}\
};\
/**/
BOOST_STATIC_LAMBDA_UNARY_OPERATOR(indirection, *)
BOOST_STATIC_LAMBDA_UNARY_OPERATOR(address_of, &)

BOOST_STATIC_LAMBDA_UNARY_OPERATOR(plus, +)
BOOST_STATIC_LAMBDA_UNARY_OPERATOR(negation, -)

BOOST_STATIC_LAMBDA_UNARY_OPERATOR(prefix_increment, ++)
BOOST_STATIC_LAMBDA_UNARY_OPERATOR(prefix_decrement, --)

BOOST_STATIC_LAMBDA_UNARY_OPERATOR(complement, ~)
BOOST_STATIC_LAMBDA_UNARY_OPERATOR(logic_negation, !)
#undef BOOST_STATIC_LAMBDA_UNARY_OPERATOR

}
}
#endif /*BOOST_STATIC_LAMBDA_OPERATOR_HPP_*/
