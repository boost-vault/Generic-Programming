#ifndef CONSTRUCT_HPP_
#define CONSTRUCT_HPP_

#include "executor.hpp"
#include "expression.hpp"
namespace boost
{
namespace static_lambda
{

namespace tag
{
#define BOOST_STATIC_LAMBDA_CONSTRUCT_TAG(z, n, _) \
template<typename Class BOOST_PP_ENUM_TRAILING_PARAMS_Z(z,n,typename Argument_Tag)> \
struct BOOST_PP_CAT(construct, n); \
/**/
BOOST_PP_REPEAT(10, BOOST_STATIC_LAMBDA_CONSTRUCT_TAG, nil)
#undef BOOST_STATIC_LAMBDA_CONSTRUCT_TAG
}


namespace expr
{
#define BOOST_STATIC_LAMBDA_GET_PARAMETER(z,n,_) \
	expression<BOOST_PP_CAT(Argument_Tag, n)>\
/**/
#define BOOST_STATIC_LAMBDA_CONSTRUCT(z, n, _) \
	template<typename Class BOOST_PP_ENUM_TRAILING_PARAMS_Z(z,n,typename Argument_Tag)>\
	expression<BOOST_PP_CAT(tag::construct, n)<Class BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, Argument_Tag)> > construct(BOOST_PP_CAT(BOOST_PP_ENUM_, z)(n, BOOST_STATIC_LAMBDA_GET_PARAMETER, nil))\
	{\
		expression<BOOST_PP_CAT(tag::construct, n)<Class BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, Argument_Tag)> > ret;\
		return ret;\
	}\
/**/


BOOST_PP_REPEAT(10, BOOST_STATIC_LAMBDA_CONSTRUCT, nil)

#undef BOOST_STATIC_LAMBDA_CONSTRUCT
#undef BOOST_STATIC_LAMBDA_GET_PARAMETER

}

#define BOOST_STATIC_LAMBDA_EXECUTE_ARGUMENT(z,n,_) \
	executor<BOOST_PP_CAT(Argument_Tag, n), Stack>::execute(stack) \
/**/
#define BOOST_STATIC_LAMBDA_CONSTRUCT_EXECUTOR(z,n,_) \
template<typename Class BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, typename Argument_Tag), typename Stack>\
struct result<BOOST_PP_CAT(tag::construct, n)<Class BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, Argument_Tag)>, Stack>\
{\
	typedef Class type;\
};\
template<typename Class BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, typename Argument_Tag), typename Stack, typename Result_Type>\
struct modified_executor<BOOST_PP_CAT(tag::construct, n)<Class BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, Argument_Tag)>, Stack, Result_Type>\
{\
	static Result_Type execute(Stack& stack)\
	{\
		return Class(BOOST_PP_CAT(BOOST_PP_ENUM_, z)(n, BOOST_STATIC_LAMBDA_EXECUTE_ARGUMENT, nil));\
	}\
};\
/**/

BOOST_PP_REPEAT(10, BOOST_STATIC_LAMBDA_CONSTRUCT_EXECUTOR, nil)
#undef BOOST_STATIC_LAMBDA_CONSTRUCT_EXECUTOR
#undef BOOST_STATIC_LAMBDA_EXECUTE_ARGUMENT

}
}



#endif /*CONSTRUCT_HPP_*/
