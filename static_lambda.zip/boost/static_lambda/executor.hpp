#ifndef EXECUTOR_HPP_
#define EXECUTOR_HPP_
namespace boost
{
namespace static_lambda
{
template<typename Tag, typename Stack>
struct result;
template<typename Tag, typename Stack, typename Result_Type>
struct modified_executor;

template<typename Tag, typename Stack>
struct executor
  : modified_executor<Tag, Stack, typename result<Tag, Stack>::type>
{
  typedef typename result<Tag, Stack>::type result_type;
};

}
}
#endif /*EXECUTOR_HPP_*/
