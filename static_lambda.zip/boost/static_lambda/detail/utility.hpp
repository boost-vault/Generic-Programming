#ifndef BOOST_STATIC_LAMBDA_DETAIL_UTILITY_HPP_
#define BOOST_STATIC_LAMBDA_DETAIL_UTILITY_HPP_

namespace boost
{
namespace static_lambda
{
namespace detail
{
template<typename T>
T make();
}
}
}

#endif /*BOOST_STATIC_LAMBDA_DETAIL_UTILITY_HPP_*/
