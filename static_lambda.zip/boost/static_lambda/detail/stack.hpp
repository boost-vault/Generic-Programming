#ifndef BOOST_STATIC_LAMBDA_DETAIL_STACK_HPP_
#define BOOST_STATIC_LAMBDA_DETAIL_STACK_HPP_
#include <boost/mpl/front.hpp>
#include <boost/mpl/size.hpp>
#include <boost/mpl/pop_front.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/identity.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/type_traits/remove_reference.hpp>
#include <boost/type_traits/add_reference.hpp>
#include <boost/static_assert.hpp>
namespace boost
{
namespace static_lambda
{
namespace detail
{
template<typename Name, typename List>
struct locator;

template<typename Type, typename Name>
struct back_node
{
	typedef Type type;
	typedef Name name_type;
	type value_;
};

template<typename Type, typename Name>
struct locator<Name, back_node<Type, Name> >
{
	typedef typename boost::add_reference<Type>::type result_type;
	static result_type get(back_node<Type, Name>& n)
	{
		return n.value_;
	}
};

template<typename Type, typename Name, typename Other_List>
struct node
{
	typedef Type type;
	typedef Name name_type;
	type value_;
	Other_List other_list_;
};

template<typename Searching_Name, typename Type, typename Name, typename Other_List>
struct locator<Searching_Name, node<Type, Name, Other_List> >
{
	typedef typename locator<Searching_Name, typename boost::remove_reference<Other_List>::type>::result_type result_type;
	static result_type get(node<Type, Name, Other_List>& n)
	{
		return locator<Searching_Name, typename boost::remove_reference<Other_List>::type>::get(n.other_list_);
	}
};

template<typename Type, typename Name, typename Other_List>
struct locator<Name, node<Type, Name, Other_List> >
{
	typedef typename boost::add_reference<Type>::type result_type;
	static result_type get(node<Type, Name, Other_List>& n)
	{
		return n.value_;
	}
};
template<typename Types, typename Names>
struct vector_node;
template<typename Types, typename Names>
struct vector_linked_node
{
	typedef boost::mpl::size<Types> number_of_types_type;
	typedef boost::mpl::size<Names> number_of_names_type;
	BOOST_STATIC_ASSERT(number_of_types_type::value == number_of_names_type::value);
	BOOST_STATIC_ASSERT(number_of_types_type::value > 1);
	typedef node
	<
		typename boost::mpl::front<Types>::type,
		typename boost::mpl::front<Names>::type,
		typename vector_node
		<
			typename boost::mpl::pop_front<Types>::type,
			typename boost::mpl::pop_front<Names>::type
		>::type
	> type;
};
template<typename Types, typename Names>
struct vector_node
{
	typedef boost::mpl::size<Types> number_of_types_type;
	typedef boost::mpl::size<Names> number_of_names_type;
	BOOST_STATIC_ASSERT(number_of_types_type::value == number_of_names_type::value);
	BOOST_STATIC_ASSERT(number_of_types_type::value > 0);
	
	typedef typename boost::mpl::eval_if_c
	<
		number_of_types_type::value == 1,
		boost::mpl::identity
		<
			back_node
			<
				typename boost::mpl::front<Types>::type,
				typename boost::mpl::front<Names>::type
			>
		>
		,
		vector_linked_node<Types, Names>
	>::type	type;
	
};

template<typename Name, typename Variants>
typename locator<Name, Variants>::result_type get(Variants& variants)
{
	return locator<Name, Variants>::get(variants);
}

}
}
}
#endif /*BOOST_STATIC_LAMBDA_DETAIL_STACK_HPP_*/
