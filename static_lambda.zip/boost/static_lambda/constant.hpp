#ifndef CONSTANT_HPP_
#define CONSTANT_HPP_
#include "executor.hpp"
#include "expression.hpp"
#include <boost/type_traits/add_reference.hpp>

namespace boost
{
namespace static_lambda
{

namespace tag
{
  template<typename Data>
  struct constant;
}

namespace expr
{
  template<typename Data>
  expression<tag::constant<Data> > constant()
  {
    return expression<tag::constant<Data> >();
  }
}

template<typename Data, typename Stack>
struct result<tag::constant<Data>, Stack>
{
  typedef typename Data::value_type type;
};

template<typename Data, typename Stack, typename Result_Type>
struct modified_executor<tag::constant<Data>, Stack, Result_Type>
{
  static Result_Type execute(Stack&)
  {
    return Data::value;
  }
};

}
}

#endif /*CONSTANT_HPP_*/
