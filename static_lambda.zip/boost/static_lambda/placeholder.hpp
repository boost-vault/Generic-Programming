#ifndef PLACEHOLDER_HPP_
#define PLACEHOLDER_HPP_

#include "executor.hpp"
#include "expression.hpp"
#include "local.hpp"
#include <boost/mpl/int.hpp>
#include <boost/mpl/list.hpp>
#include <boost/mpl/max_element.hpp>
#include <boost/mpl/deref.hpp>
#include <boost/preprocessor/repetition/enum.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/arithmetic/inc.hpp>
namespace boost
{
namespace static_lambda
{
namespace tag
{
	template<int N>
	struct placeholder;
}	
	template<typename Expression>
	struct number_of_arguments : boost::mpl::int_<0> {};


#define BOOST_STATIC_LAMBDA_NUMBER_OF_ARGUMENTS_TEMPLATE(z, n, _) \
	number_of_arguments<BOOST_PP_CAT(Expression, n)> \
/**/
#define BOOST_STATIC_LAMBDA_NUMBER_OF_ARGUMENTS(z, n, _) \
	template<template<BOOST_PP_ENUM_PARAMS_Z(z, n, typename Expression)> class Tag,\
		BOOST_PP_ENUM_PARAMS_Z(z, n, typename Expression)>\
	struct number_of_arguments<Tag<BOOST_PP_ENUM_PARAMS_Z(z, n, Expression)> >\
		: boost::mpl::deref<typename boost::mpl::max_element<boost::mpl::list \
		<\
			BOOST_PP_CAT(BOOST_PP_ENUM_, z)(n, BOOST_STATIC_LAMBDA_NUMBER_OF_ARGUMENTS_TEMPLATE, nil) \
		> >::type>::type {};\
/**/

#define BOOST_STATIC_LAMBDA_NUMBER_OF_ARGUMENTS_INC(z,n,_) \
	BOOST_STATIC_LAMBDA_NUMBER_OF_ARGUMENTS(z, BOOST_PP_INC(n),_)
/**/
BOOST_PP_REPEAT(9, BOOST_STATIC_LAMBDA_NUMBER_OF_ARGUMENTS_INC, nil)
#undef BOOST_STATIC_LAMBDA_NUMBER_OF_ARGUMENTS
#undef BOOST_STATIC_LAMBDA_EXPRESSION_OPERATOR_FUNCTION_CALL_INC
#undef BOOST_STATIC_LAMBDA_NUMBER_OF_ARGUMENTS_TEMPLATE
	
	template<int N>
	struct number_of_arguments<tag::placeholder<N> >
		: boost::mpl::int_<N + 1> {};
		


namespace
{
	expression<tag::get<tag::placeholder<0> > > _1;
	expression<tag::get<tag::placeholder<1> > > _2;
	expression<tag::get<tag::placeholder<2> > > _3;
	expression<tag::get<tag::placeholder<3> > > _4;
	expression<tag::get<tag::placeholder<4> > > _5;
	expression<tag::get<tag::placeholder<5> > > _6;
	expression<tag::get<tag::placeholder<6> > > _7;
	expression<tag::get<tag::placeholder<7> > > _8;
	expression<tag::get<tag::placeholder<8> > > _9;
}
}
}

#endif /*PLACEHOLDER_HPP_*/
