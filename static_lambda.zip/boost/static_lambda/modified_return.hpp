#ifndef MODIFIED_RETURN_HPP_
#define MODIFIED_RETURN_HPP_

#include "executor.hpp"
#include "expression.hpp"
#include <boost/type_traits/add_reference.hpp>
#include <boost/type_traits/add_const.hpp>
namespace boost
{
namespace static_lambda
{
namespace tag
{
template<typename>
struct add_reference;
template<typename>
struct add_const;
}

namespace expr
{
  template<typename Tag>
  expression<tag::add_reference<Tag> > add_reference(expression<Tag>)
  {
    expression<tag::add_reference<Tag> > ret;
    return ret;
  }

}
template<typename Inner_Tag, typename Stack>
struct result<tag::add_reference<Inner_Tag>, Stack>
  : boost::add_reference<typename result<Inner_Tag, Stack>::type> {};

template<typename Tag, typename Stack, typename Result_Type>
struct modified_executor<tag::add_reference<Tag>, Stack, Result_Type>
  : modified_executor<Tag, Stack, Result_Type> {};

}
}

#endif /*MODIFIED_RETURN_HPP_*/
