#ifndef FUNCTOR_HPP_
#define FUNCTOR_HPP_
#include "placeholder.hpp"
#include "detail/stack.hpp"
#include <boost/type_traits/add_reference.hpp>
#include <boost/mpl/list.hpp>
#include <boost/mpl/void.hpp>
#include <boost/preprocessor/repetition/enum_binary_params.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/enum.hpp>
#include <boost/preprocessor/arithmetic/inc.hpp>

namespace boost
{
namespace static_lambda
{

template<typename Tag, int Number_Of_Arguments>
struct functor_operator_call;

template<typename Tag>
struct functor_operator_call<Tag, 0>
{
	typename executor<Tag, boost::mpl::void_>::result_type operator()()
	{
		boost::mpl::void_ empty_stack;
		return executor<Tag, boost::mpl::void_>::execute(empty_stack);
	}
};

#define BOOST_STATIC_LAMBDA_PLACEHOLDER(z,n,_) tag::placeholder<n>

#define BOOST_STATIC_LAMBDA_FUNCTOR_OPERATOR_CALL(z, n, _)\
template<typename Tag>\
struct functor_operator_call<Tag, n>\
{\
	template<BOOST_PP_ENUM_PARAMS_Z(z, n, typename T)>\
	static typename executor\
	<\
		Tag,\
		typename detail::vector_node\
		<\
			boost::mpl::list<BOOST_PP_ENUM_PARAMS_Z(z, n, T)>,\
			boost::mpl::list<BOOST_PP_CAT(BOOST_PP_ENUM_, z)(n, BOOST_STATIC_LAMBDA_PLACEHOLDER, nil) >\
		>::type\
	>::result_type static_invoke(BOOST_PP_ENUM_BINARY_PARAMS_Z(z, n, T, t))\
	{\
		typename detail::vector_node\
		<\
			boost::mpl::list<BOOST_PP_ENUM_PARAMS_Z(z, n, T)>,\
			boost::mpl::list<BOOST_PP_CAT(BOOST_PP_ENUM_, z)(n, BOOST_STATIC_LAMBDA_PLACEHOLDER, nil) >\
		>::type v = {BOOST_PP_ENUM_PARAMS_Z(z, n, t)};\
		return executor\
		<\
			Tag,\
			typename detail::vector_node\
			<\
				boost::mpl::list<BOOST_PP_ENUM_PARAMS_Z(z, n, T)>,\
				boost::mpl::list<BOOST_PP_CAT(BOOST_PP_ENUM_, z)(n, BOOST_STATIC_LAMBDA_PLACEHOLDER, nil) >\
			>::type\
		>::execute(v);\
	}\
	template<BOOST_PP_ENUM_PARAMS_Z(z, n, typename T)>\
	typename executor\
	<\
		Tag,\
		typename detail::vector_node\
		<\
			boost::mpl::list<BOOST_PP_ENUM_PARAMS_Z(z, n, T)>,\
			boost::mpl::list<BOOST_PP_CAT(BOOST_PP_ENUM_, z)(n, BOOST_STATIC_LAMBDA_PLACEHOLDER, nil) >\
		>::type\
	>::result_type operator()(BOOST_PP_ENUM_BINARY_PARAMS_Z(z, n, T, t))\
	{\
		typename detail::vector_node\
		<\
			boost::mpl::list<BOOST_PP_ENUM_PARAMS_Z(z, n, T)>,\
			boost::mpl::list<BOOST_PP_CAT(BOOST_PP_ENUM_, z)(n, BOOST_STATIC_LAMBDA_PLACEHOLDER, nil) >\
		>::type v = {BOOST_PP_ENUM_PARAMS_Z(z, n, t)};\
		return executor\
		<\
			Tag,\
			typename detail::vector_node\
			<\
				boost::mpl::list<BOOST_PP_ENUM_PARAMS_Z(z, n, T)>,\
				boost::mpl::list<BOOST_PP_CAT(BOOST_PP_ENUM_, z)(n, BOOST_STATIC_LAMBDA_PLACEHOLDER, nil) >\
			>::type\
		>::execute(v);\
	}\
};\
/**/
#define BOOST_STATIC_LAMBDA_FUNCTOR_OPERATOR_CALL_INC(z, n, _) \
	BOOST_STATIC_LAMBDA_FUNCTOR_OPERATOR_CALL(z, BOOST_PP_INC(n), _) \
/**/

BOOST_PP_REPEAT(9, BOOST_STATIC_LAMBDA_FUNCTOR_OPERATOR_CALL_INC, 0)
#undef BOOST_STATIC_LAMBDA_FUNCTOR_OPERATOR_CALL_INC
#undef BOOST_STATIC_LAMBDA_FUNCTOR_OPERATOR_CALL
#undef BOOST_STATIC_LAMBDA_PLACEHOLDER
template<typename Tag>
struct functor : functor_operator_call<Tag, number_of_arguments<Tag>::value>
{
	enum {number_of_arguments = number_of_arguments<Tag>::value};
};


template<typename Tag>
static functor<Tag> to_functor(expression<Tag>)
{
	return functor<Tag>();
}
namespace tag
{
	template<typename>
	struct construct0;
}
template<typename Expression>
expression<tag::construct0<functor<Expression> > > to_functor_expression(Expression)
{
	expression<tag::construct0<functor<Expression> > > ret;
	return ret;
}
template<typename Expression>
expression<tag::construct0<functor<Expression> > > to_expression(functor<Expression>)
{
	expression<tag::construct0<functor<Expression> > > ret;
	return ret;
}
}
}
#endif /*FUNCTOR_HPP_*/
