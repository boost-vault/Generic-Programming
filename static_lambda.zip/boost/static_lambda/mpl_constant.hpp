#ifndef MPL_CONSTANT_HPP_
#define MPL_CONSTANT_HPP_
#include "constant.hpp"
#include <boost/mpl/int.hpp>
#include <boost/mpl/size_t.hpp>
#include <boost/mpl/long.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/integral_c.hpp>
namespace boost
{
namespace static_lambda
{

namespace expr
{
	
template<typename T, T N>
expression<tag::constant<boost::mpl::integral_c<T, N> > > integral_c()
{
	expression<tag::constant<boost::mpl::integral_c<T, N> > > ret;
	return ret;
}
	
template<std::size_t N>
expression<tag::constant<boost::mpl::size_t<N> > > size_t()
{
	expression<tag::constant<boost::mpl::size_t<N> > > ret;
	return ret;
}
	
template<long N>
expression<tag::constant<boost::mpl::long_<N> > > long_()
{
	expression<tag::constant<boost::mpl::long_<N> > > ret;
	return ret;
}
	
template<int N>
expression<tag::constant<boost::mpl::int_<N> > > int_()
{
	expression<tag::constant<boost::mpl::int_<N> > > ret;
	return ret;
}
	
template<bool C>
expression<tag::constant<boost::mpl::bool_<C> > > bool_()
{
	expression<tag::constant<boost::mpl::bool_<C> > > ret;
	return ret;
}

}
}
}
#endif /*MPL_CONSTANT_HPP_*/
