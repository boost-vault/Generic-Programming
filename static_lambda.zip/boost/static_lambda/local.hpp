#ifndef LOCAL_HPP_
#define LOCAL_HPP_

#include "executor.hpp"
#include "expression.hpp"
#include "detail/stack.hpp"
namespace boost
{
  namespace static_lambda
  {
    namespace tag
    {

      template<typename>
      struct get;

      template<typename Name, typename Value, typename Scope>
      struct auto_local;

#define BOOST_STATIC_LAMBDA_LOCAL_TAG(z, n, _) \
  template<typename Class, typename Name BOOST_PP_ENUM_TRAILING_PARAMS_Z(z,n,typename Argument_Tag), typename Scope> \
      struct BOOST_PP_CAT(local, n); \
      /**/
      BOOST_PP_REPEAT(10, BOOST_STATIC_LAMBDA_LOCAL_TAG, nil)
#undef BOOST_STATIC_LAMBDA_LOCAL_TAG
    }

    namespace expr
    {
      template<typename Name>
        expression<tag::get<Name> > get()
      {
        expression<tag::get<Name> > ret;
        return ret; 
      }

      template<typename Name, typename Value, typename Scope>
        expression<tag::auto_local<Name, Value, Scope> > local(expression<Value>, expression<Scope>)
      {
        expression<tag::auto_local<Name, Value, Scope> > ret;
        return ret;
      }

#define BOOST_STATIC_LAMBDA_GET_PARAMETER(z,n,_) \
  expression<BOOST_PP_CAT(Argument_Tag, n)>,\
  /**/
#define BOOST_STATIC_LAMBDA_LOCAL_EXPRESSION(z, n, _) \
  template<typename Class, typename Name BOOST_PP_ENUM_TRAILING_PARAMS_Z(z,n,typename Argument_Tag), typename Scope>\
  expression<BOOST_PP_CAT(tag::local, n)<Class, Name BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, Argument_Tag), Scope> > local(BOOST_PP_CAT(BOOST_PP_REPEAT_, z)(n, BOOST_STATIC_LAMBDA_GET_PARAMETER, nil) expression<Scope>)\
      {\
      expression<BOOST_PP_CAT(tag::local, n)<Class, Name BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, Argument_Tag), Scope> > ret;\
      return ret;\
      }\
      /**/


      BOOST_PP_REPEAT(10, BOOST_STATIC_LAMBDA_LOCAL_EXPRESSION, nil)

#undef BOOST_STATIC_LAMBDA_LOCAL_EXPRESSION
#undef BOOST_STATIC_LAMBDA_GET_PARAMETER

    }	

#define BOOST_STATIC_LAMBDA_EXECUTE_ARGUMENT(z,n,_) \
  executor<BOOST_PP_CAT(Argument_Tag, n), Stack>::execute(stack) \
  /**/
#define BOOST_STATIC_LAMBDA_LOCAL_EXECUTOR(z,n,_) \
  template<typename Class, typename Name BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, typename Argument_Tag), typename Scope, typename Stack>\
    struct result<BOOST_PP_CAT(tag::local, n)<Class, Name BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, Argument_Tag), Scope>, Stack>\
    {\
    typedef typename executor<Scope, detail::node<Class&, Name, Stack&> >::result_type type;\
    };\
    template<typename Class, typename Name BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, typename Argument_Tag), typename Scope, typename Stack, typename Result_Type>\
    struct modified_executor<BOOST_PP_CAT(tag::local, n)<Class, Name BOOST_PP_ENUM_TRAILING_PARAMS_Z(z, n, Argument_Tag), Scope>, Stack, Result_Type>\
    {\
    static Result_Type execute(Stack& stack)\
    {\
    detail::node<Class, Name, Stack&> inner_stack = {Class (BOOST_PP_CAT(BOOST_PP_ENUM_, z)(n, BOOST_STATIC_LAMBDA_EXECUTE_ARGUMENT, nil)), stack};\
    return executor<Scope, detail::node<Class, Name, Stack&> >::execute(inner_stack);\
    }\
    };\
    /**/

    BOOST_PP_REPEAT(10, BOOST_STATIC_LAMBDA_LOCAL_EXECUTOR, nil)
#undef BOOST_STATIC_LAMBDA_LOCAL_EXECUTOR
#undef BOOST_STATIC_LAMBDA_EXECUTE_ARGUMENT


      template<typename Name, typename Stack>
      struct result<tag::get<Name>, Stack>
      {
        typedef typename detail::locator<Name, Stack>::result_type type;
      };
      template<typename Name, typename Stack, typename Result_Type>
      struct modified_executor<tag::get<Name>, Stack, Result_Type>
      {
        static Result_Type execute(Stack& stack)
        {
          return detail::get<Name>(stack);
        }
      };

      template<typename Name, typename Value, typename Scope, typename Stack>
      struct result<tag::auto_local<Name, Value, Scope>, Stack>
      {
        typedef typename executor
        <
          Scope,
          detail::node
          <
            typename executor<Value, Stack>::result_type,
            Name,
            Stack&
          >
        >::result_type type;
      };
      template<typename Name, typename Value, typename Scope, typename Stack, typename Result_Type>
      struct modified_executor<tag::auto_local<Name, Value, Scope>, Stack, Result_Type>
      {
        static Result_Type execute(Stack& stack)
        {
          detail::node
          <
            typename executor<Value, Stack>::result_type,
            Name,
            Stack&
          > inner_stack = {executor<Value, Stack>::execute(stack), stack};
          return executor
          <
            Scope,
            detail::node
            <
              typename executor<Value, Stack>::result_type,
              Name,
              Stack&
            >
          >::execute(inner_stack);
        }
      };

  }
}

#endif /*LOCAL_HPP_*/
