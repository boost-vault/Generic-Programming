#ifndef STATIC_LAMBDA_HPP_
#define STATIC_LAMBDA_HPP_
#include "static_lambda/operator.hpp"
#include "static_lambda/functor.hpp"
#include "static_lambda/inplace_executor.hpp"
#include "static_lambda/placeholder.hpp"
#include "static_lambda/local.hpp"
#include "static_lambda/construct.hpp"
#include "static_lambda/constant.hpp"
#include "static_lambda/mpl_constant.hpp"
#include "static_lambda/modified_return.hpp"
namespace boost
{
namespace static_lambda
{
using namespace ::boost::static_lambda::expr;
}
}
#define BOOST_STATIC_LAMBDA_FUNCTOR(expr) \
  BOOST_TYPEOF( ::boost::static_lambda::to_functor(expr))\
/**/
#endif /*STATIC_LAMBDA_HPP_*/
