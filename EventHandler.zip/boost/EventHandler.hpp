//Header File
//Name     : event_handler.h
//Language : C++
//Contains : event_handler
//
//Notes    : I would like to apologise for any spelling errors in this file
//Author   : Jake Hall
//Copyright: Jake Hall
//Date     : 23rd August 2007
//License  : Free to use for Commercial or Non-commercial without restriction under Boost Software License - Version 1.0 - August 17th, 2003

//Template
//value "returntype" : The return type of the callback function from "event_handler" class
//value "parameter"  : The argument type the callback function will take
//
template<class returntype = int, class parameter = int>

//Class
//Name : event_handler
//
//Description : A class to help create callbacks from inside other classes
//
class event_handler{

	//Variable
	//Name        : function
	//Type        : returntype(*)(parameter)
	//
	//Description : Function pointer to a callback function
	//
	returntype(*function)(parameter);

public:

	//Constructor
	//Name        : event_handler
	//Return Type : N/A
	//parameter   : void
	//
	//Description : Initialize the function pointer to 0 (NULL)
	//
	event_handler(){
		function = 0;
	}//End of event_handler(void)

	//Overloaded Constructor
	//Name             : event_handler
	//Return Type      : N/A
	//parameter "func" : Function pointer to callback function
	//
	//Description      :Sets function pointer to that of the passed pointer "func:
	//
	event_handler(returntype(*func)(parameter)){
		function = func;
	}//End of event_handler(returntype(*)(parameter))

	//Function
	//Name        : Destructor
	//Return Type : N/A
	//parameter   : void
	//
	//Description : Reset "function" to 0 (NULL)
	//
	~event_handler(){
		function = 0;
	}//End of ~event_handler(void)

	//Function
	//Name             : set_event_callback
	//Return Type      : Void
	//parameter "func" : Function pointer to callback function
	//
	//Description      : Sets function pointer to that of the passed pointer "func"
	//
	void set_event_callback(returntype(*func)(parameter)){
		function = func;
	}// End of set_event_callback(returntype(*)(parameter))

	//Function
	//Name              : invoke
	//Return Type       : returntype (Default int)
	//parameter "value" : parameter (Defualt int)
	//
	//Description       : Calls the callback function if it is defined, otherwide returns 0 (NULL)
	//
	returntype invoke(parameter value){
		if(function != 0){
			return function(value);
		}else{
			return (returntype)value;
		}
	}//End of invoke(parameter)
};//End of event_handler