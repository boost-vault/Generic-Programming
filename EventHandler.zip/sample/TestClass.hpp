//Header File
//Name     : test_class.h
//Language : C++
//Contains : test_class
//
//Notes    : A test class to demonstrate the event_handler
//Author   : Jake Hall
//Copyright: Jake Hall
//Date     : 23rd August 2007
//License  : Free to use for Commercial or Non-commercial without restriction under Boost Software License - Version 1.0 - August 17th, 2003

//Class
//Name        : test_class
//
//Description : A test class to demonstrate the event_handler
//
class test_class{

	//Variable
	//Name        : value
	//Type        : int
	//
	//Description : Local storage of a number
	//
	int value;

public:

	//Object
	//Name           : on_valueChanged
	//Type           : event_handler
	//Template Types : int, int
	//
	//Descriptiont   : The event handler for when the value of "value" is changed
	//
	event_handler<int, int> * on_valueChanged;

	//Constructor
	//Name        : test_class
	//Return Type : N/A
	//parameter   : void
	//
	//Description : Initializes value to 0 and create an instance if event_handler in onValuechanged
	//
	test_class(){
		value = 0;
		on_valueChanged = new event_handler<int,int>();
	}//End of test_class(void)

	//Destructor
	//Name        : ~test_class
	//Return Type : N/A
	//parameter   : void
	//
	//Description : frees the memory being used by this classes variables
	//
	~test_class(){
		delete &value;
		delete on_valueChanged;
	}//End of ~test_class(void)

	//Function
	//Name              : set_value
	//Return Type       : void
	//parameter "value" : int
	//
	//Description       : Set value while invoking the on_valueChanged event
	//
	void set_value(int value){
		value = on_valueChanged->invoke(value);
	}//End of set_value(int)

	//Function
	//Name        : get_value
	//Return Type : int
	//parameter   : void
	//
	//Description : Returns the value of value 
	//
	int get_value(void){
		return value;
	}//End of get_value(void)
};//End of test_class