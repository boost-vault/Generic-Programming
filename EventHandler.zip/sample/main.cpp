//Source File
//Name : main.cpp
//Language : C++
//Contains : Program Entry Point
//Notes    : A test class to demonstrate the event_handler
//
//Author   : Jake Hall
//Copyright: Jake Hall
//Date     : 23rd August 2007
//License  : Free to use for Commercial or Non-commercial without restriction under Boost Software License - Version 1.0 - August 17th, 2003

#include <stdio.h>
#include <stdlib.h>

#include "..\event_handler.hpp"
#include "test_class.hpp"

//Function
//Name              : on_valueChanged
//Return Type       : int
//parameter "value" : int
//
//Description       : The callback function for test_class
//					: multiplies TestClasses value by 3
//
int on_valueChanged(int value){
	return (value * 3);
}

//Function
//Name             : main
//Return Type      : int
//Paramater "argv" : int
//parameter "argc" : char[]
//
//Description      : Program entry point
//
int main(int argv ,char argc[]){
	//Object
	//Name : test
	//Type : test_class
	//
	//Description : an instance of the test_class
	//
	test_class * test = new test_class();

	//Note : Sets the callback of on_valueChanged Event to on_valueChanged(int)
	test->on_valueChanged->set_event_function(on_valueChanged);

	//Note : Sets value to 4
	//     : 4 is then passed to callback
	test->set_value(4);

	//Note   : Prints value having been passed through onValuechanged
	//       : Should have been multiplied by 3
	//Output : "test->value = 12"
	printf("test->value = %d\n", test->get_value());

	//Note : Messy OS dependant way of pausing the program
	//     : replace this with your own pause method, this is used for code readability
	system("PAUSE");

	return 0;
}